# Synapse
Synapse.exe: windows;
No linux yet;
Will be no mac;
